import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '5mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Chatbot Endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, currentDay, currentProblem, userCode, language, preferredLanguage, userLevel, userProfile } = req.body;

    const studentName = userProfile?.name || 'Student';
    const courseTrack = userProfile?.selectedCourse || 'General';

    const langInstruction =
      'Communicate exclusively in clear, professional, friendly, and encouraging English. Provide clean step-by-step explanations and structured answers.';

    const systemInstruction = `You are "Kani / கணி", an expert AI Teacher & Mentor guiding student "${studentName}" through their 50-Day Course (${courseTrack} track).
Student Context:
- Student Name: ${studentName}
- Selected Course Track: ${courseTrack}
- Current Bootcamp Day: Day ${currentDay || 1}
- User Assessed Skill Level: ${userLevel || 'Beginner'}
- Active Problem/Topic: ${currentProblem ? JSON.stringify(currentProblem.title) : 'General learning'}
- Programming/Calculation Mode: ${language || 'JavaScript'}
- Current Code/Solution in Editor:
\`\`\`
${userCode || '// No code written yet'}
\`\`\`

Language Preference:
${langInstruction}

Pedagogical Style:
1. Address the student warmly by their name ("${studentName}").
2. If the course is Aptitude: explain formulas, fast shortcut tricks (மனக்கணக்கு), time-saving tips for campus placements (TCS, Infosys, Zoho, etc.).
3. If the course is Coding: explain logic, syntax, Big-O time and space complexity, and debugging steps.
4. Never give away the full final solution immediately unless explicitly asked. Guide them with hints, analogies, and questions (Socratic method).
5. Format formulas and code blocks cleanly. Keep responses concise, structured, and easy to read.`;

    const contents = (messages || []).map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // If contents is empty or invalid, fallback
    if (contents.length === 0) {
      contents.push({
        role: 'user',
        parts: [{ text: 'Vanakkam! Please introduce yourself and how you can guide me in this 50-day coding course.' }],
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'Mannikkavum, oru siru error vanthuduchu. Please try asking again!';
    res.json({ reply });
  } catch (error: any) {
    console.error('Chat error:', error);
    res.status(500).json({
      error: 'Failed to process chat message',
      details: error?.message || 'Server error',
      reply: 'Ennala ippo connect panna mudiyala. Please check your network or try again in a moment! (Network / Gemini connection issue)',
    });
  }
});

// Code Evaluation & Review Endpoint
app.post('/api/evaluate-code', async (req: Request, res: Response) => {
  try {
    const { problem, code, language, preferredLanguage, testCases } = req.body;

    const langInstruction =
      'Write the explanation, feedback, and edge-cases in clear, concise, professional English.';

    const prompt = `You are an automated code judge and expert mentor.
Analyze the student's solution for the following programming problem:

PROBLEM:
Title: ${problem?.title || 'Daily Challenge'}
Description: ${problem?.description || ''}
Difficulty: ${problem?.difficulty || 'Medium'}
Constraints: ${problem?.constraints || ''}

TEST CASES:
${JSON.stringify(testCases || [], null, 2)}

STUDENT CODE (${language}):
\`\`\`${language}
${code}
\`\`\`

Language feedback style: ${langInstruction}

Task:
1. Check correctness against every test case. For each test case, determine if the student code passes, what the expected output is, and what the actual output would be.
2. Determine Time Complexity (Big O) and Space Complexity (Big O).
3. Evaluate overall status: "passed" (all test cases succeed), "partial" (some fail or edge cases fail), or "failed" (syntax error, logic failure).
4. Provide constructive mentor feedback, strengths, potential edge cases to watch out for, and an optimization tip.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallStatus: {
              type: Type.STRING,
              description: 'One of: passed, partial, failed',
            },
            scorePercent: {
              type: Type.INTEGER,
              description: 'Score from 0 to 100',
            },
            timeComplexity: {
              type: Type.STRING,
              description: 'e.g. O(N), O(N log N)',
            },
            spaceComplexity: {
              type: Type.STRING,
              description: 'e.g. O(1), O(N)',
            },
            testResults: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  input: { type: Type.STRING },
                  expected: { type: Type.STRING },
                  actual: { type: Type.STRING },
                  passed: { type: Type.BOOLEAN },
                  explanation: { type: Type.STRING },
                },
                required: ['input', 'expected', 'actual', 'passed'],
              },
            },
            mentorFeedback: {
              type: Type.STRING,
              description: 'Encouraging breakdown of how they did in preferred language',
            },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            improvements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            edgeCasesConsidered: {
              type: Type.STRING,
              description: 'Note on edge cases handled or missed',
            },
          },
          required: ['overallStatus', 'scorePercent', 'timeComplexity', 'spaceComplexity', 'testResults', 'mentorFeedback'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Code evaluation error:', error);
    res.status(500).json({
      error: 'Failed to evaluate code',
      details: error?.message,
    });
  }
});

// Diagnostic & Level Assessment Evaluator Endpoint
app.post('/api/evaluate-diagnostic', async (req: Request, res: Response) => {
  try {
    const { answers, questions, preferredLanguage } = req.body;

    const prompt = `Evaluate the student's coding diagnostic assessment to determine their exact skill level:
Student answers:
${JSON.stringify(answers, null, 2)}

Questions:
${JSON.stringify(questions, null, 2)}

Provide:
1. Overall assessed level: "Beginner" (Level 1), "Intermediate" (Level 2), or "Advanced" (Level 3).
2. Level title (e.g. "Beginner Explorer", "Intermediate Architect", "Advanced Problem Solver").
3. Recommended start day in 50-day course (Day 1, Day 11, or Day 21).
4. Category skill breakdown scores from 0-100: Logic & Problem Solving, Syntax & Concepts, Data Structures, Algorithms & Optimization.
5. Personalized roadmap strategy in ${preferredLanguage || 'Tanglish'} explaining their strengths and recommended focus.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            level: { type: Type.STRING, description: 'Beginner, Intermediate, or Advanced' },
            levelTitle: { type: Type.STRING },
            recommendedStartDay: { type: Type.INTEGER },
            scorePercent: { type: Type.INTEGER },
            categories: {
              type: Type.OBJECT,
              properties: {
                logic: { type: Type.INTEGER },
                syntax: { type: Type.INTEGER },
                dataStructures: { type: Type.INTEGER },
                algorithms: { type: Type.INTEGER },
              },
              required: ['logic', 'syntax', 'dataStructures', 'algorithms'],
            },
            summary: { type: Type.STRING },
            actionPlan: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['level', 'levelTitle', 'recommendedStartDay', 'scorePercent', 'categories', 'summary', 'actionPlan'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Diagnostic error:', error);
    res.status(500).json({
      error: 'Failed to evaluate diagnostic',
      details: error?.message,
    });
  }
});

// Dynamic AI Mock Test Generator
app.post('/api/generate-mocktest', async (req: Request, res: Response) => {
  try {
    const { topic, difficulty, numQuestions = 5, preferredLanguage = 'tanglish' } = req.body;

    const prompt = `Generate a 5-question coding mock test for topic: "${topic || 'General Programming & DSA'}", difficulty: "${difficulty || 'Medium'}".
Include:
- 2 conceptual multiple-choice questions
- 2 "What is the output of this code snippet?" questions
- 1 time/space complexity or bug identification question

Language style: Questions can have bilingual descriptions/explanations in ${preferredLanguage}.
Make sure each question has 4 distinct options, 0-indexed correctOption, and a clear explanation.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            topic: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  question: { type: Type.STRING },
                  codeSnippet: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctOptionIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                  tanglishTip: { type: Type.STRING },
                },
                required: ['id', 'question', 'options', 'correctOptionIndex', 'explanation'],
              },
            },
          },
          required: ['title', 'topic', 'difficulty', 'questions'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Generate mocktest error:', error);
    res.status(500).json({ error: 'Failed to generate mock test', details: error?.message });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Vite or Static files handling
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Code50 Server listening on port ${PORT} (NODE_ENV=${process.env.NODE_ENV || 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
