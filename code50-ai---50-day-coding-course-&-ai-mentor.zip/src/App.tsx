import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ProblemWorkspace } from './components/ProblemWorkspace';
import { CurriculumRoadmap } from './components/CurriculumRoadmap';
import { DiagnosticModal } from './components/DiagnosticModal';
import { MockTestView } from './components/MockTestView';
import { ChatbotDrawer } from './components/ChatbotDrawer';
import { OnboardingModal } from './components/OnboardingModal';
import { DAYS_CURRICULUM } from './data/curriculum';
import { APTITUDE_CURRICULUM } from './data/aptitudeCurriculum';
import { loadUserProgress, saveUserProgress, INITIAL_PROGRESS } from './utils/storage';
import { PreferredLanguage, UserProgress, UserProfile } from './types';
import { Sparkles, Award, ArrowRight } from 'lucide-react';

export default function App() {
  const [progress, setProgress] = useState<UserProgress>(() => loadUserProgress());
  const [currentTab, setCurrentTab] = useState<'workspace' | 'roadmap' | 'diagnostic' | 'mocktest'>('workspace');
  const [preferredLanguage, setPreferredLanguage] = useState<PreferredLanguage>('english');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInitialPrompt, setChatInitialPrompt] = useState<string | undefined>(undefined);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  useEffect(() => {
    if (!progress.userProfile) {
      setIsProfileModalOpen(true);
    }
  }, []);

  useEffect(() => {
    saveUserProgress(progress);
  }, [progress]);

  const activeCurriculum =
    progress.userProfile?.selectedCourse === 'aptitude'
      ? APTITUDE_CURRICULUM
      : DAYS_CURRICULUM;

  const currentDayData =
    activeCurriculum.find((d) => d.day === progress.currentDay) || activeCurriculum[0];

  const currentSavedCode =
    progress.savedCodes[progress.currentDay]?.['javascript'] || undefined;

  const handleSelectDay = (day: number) => {
    setProgress((prev) => ({ ...prev, currentDay: day }));
    setCurrentTab('workspace');
  };

  const handleCodeChange = (newCode: string) => {
    setProgress((prev) => ({
      ...prev,
      savedCodes: {
        ...prev.savedCodes,
        [progress.currentDay]: {
          ...(prev.savedCodes[progress.currentDay] || {}),
          javascript: newCode,
        },
      },
    }));
  };

  const handleDayCompleted = (day: number, xpReward: number) => {
    setProgress((prev) => {
      const isAlreadyCompleted = prev.completedDays.includes(day);
      const newCompleted = isAlreadyCompleted ? prev.completedDays : [...prev.completedDays, day];
      const newXp = isAlreadyCompleted ? prev.totalXp : prev.totalXp + xpReward;

      return {
        ...prev,
        completedDays: newCompleted,
        totalXp: newXp,
      };
    });
  };

  const handleToggleBookmark = (day: number) => {
    setProgress((prev) => {
      const isBookmarked = prev.bookmarkedDays.includes(day);
      return {
        ...prev,
        bookmarkedDays: isBookmarked
          ? prev.bookmarkedDays.filter((d) => d !== day)
          : [...prev.bookmarkedDays, day],
      };
    });
  };

  const handleAssessmentComplete = (result: any) => {
    setProgress((prev) => ({
      ...prev,
      assessedLevel: result.level,
      assessedLevelTitle: result.levelTitle,
      diagnosticCompleted: true,
      diagnosticResult: result,
      currentDay: result.recommendedStartDay,
    }));
  };

  const handleMockTestComplete = (day: number, score: number, xpReward: number) => {
    setProgress((prev) => ({
      ...prev,
      totalXp: prev.totalXp + xpReward,
      mockTestScores: {
        ...prev.mockTestScores,
        [day]: score,
      },
    }));
  };

  const handleOpenChatWithPrompt = (prompt: string) => {
    setChatInitialPrompt(prompt);
    setIsChatOpen(true);
  };

  const handleSaveProfile = (profile: UserProfile) => {
    setProgress((prev) => ({
      ...prev,
      userProfile: profile,
    }));
    setIsProfileModalOpen(false);
  };

  const handleResetProgress = () => {
    if (window.confirm('Are you sure you want to reset all course progress?')) {
      setProgress(INITIAL_PROGRESS);
      saveUserProgress(INITIAL_PROGRESS);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Global Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        preferredLanguage={preferredLanguage}
        setPreferredLanguage={setPreferredLanguage}
        completedCount={progress.completedDays.length}
        currentDay={progress.currentDay}
        streak={progress.streak}
        totalXp={progress.totalXp}
        assessedLevel={progress.assessedLevel}
        userProfile={progress.userProfile}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenChat={() => {
          setChatInitialPrompt(undefined);
          setIsChatOpen(true);
        }}
        onResetProgress={handleResetProgress}
      />

      {/* Course & Student Quick Banner */}
      {progress.userProfile && (
        <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-400 font-medium">Student:</span>
              <strong className="text-white font-bold">{progress.userProfile.name}</strong>
              <span className="text-slate-500 hidden sm:inline">({progress.userProfile.email})</span>
              <span className="text-slate-600 hidden md:inline">•</span>
              <span className="text-cyan-300 hidden md:inline">{progress.userProfile.mobile}</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-400">Selected Track:</span>
              <span className="px-2.5 py-0.5 rounded-lg bg-cyan-950 text-cyan-300 font-bold border border-cyan-800">
                {progress.userProfile.selectedCourse === 'aptitude'
                  ? 'Placement Aptitude & Reasoning Track'
                  : progress.userProfile.selectedCourse === 'coding_combo'
                  ? 'Tech + Aptitude Dual Combo'
                  : progress.userProfile.selectedCourse === 'python_dsa'
                  ? 'Python & Problem Solving'
                  : progress.userProfile.selectedCourse === 'javascript_dsa'
                  ? 'Full-Stack JavaScript & DSA'
                  : 'Java & MNC Placement'}
              </span>
              <button
                onClick={() => setIsProfileModalOpen(true)}
                className="text-slate-400 hover:text-white underline text-[11px] cursor-pointer ml-1"
              >
                Change Course / Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Diagnostic Suggestion for un-assessed users */}
      {!progress.diagnosticCompleted && currentTab !== 'diagnostic' && (
        <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/40 border-b border-blue-800/40 py-2.5 px-4 text-xs flex flex-wrap items-center justify-between gap-2 max-w-7xl mx-auto w-full">
          <div className="flex items-center gap-2 text-cyan-300 font-semibold">
            <Award className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Welcome {progress.userProfile?.name || 'Student'}! Take our 8-question diagnostic test to benchmark your skill level and get a recommended starting day.
            </span>
          </div>
          <button
            onClick={() => setCurrentTab('diagnostic')}
            className="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
          >
            <span>Start Level Assessment</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Tab Content View */}
      <main className="grow py-6">
        {currentTab === 'workspace' && (
          <ProblemWorkspace
            dayData={currentDayData}
            preferredLanguage={preferredLanguage}
            savedCode={currentSavedCode}
            isCompleted={progress.completedDays.includes(progress.currentDay)}
            onCodeChange={handleCodeChange}
            onDayCompleted={handleDayCompleted}
            onOpenChatWithPrompt={handleOpenChatWithPrompt}
            onNextDay={() => {
              if (progress.currentDay < 50) {
                handleSelectDay(progress.currentDay + 1);
              }
            }}
          />
        )}

        {currentTab === 'roadmap' && (
          <CurriculumRoadmap
            currentDay={progress.currentDay}
            completedDays={progress.completedDays}
            bookmarkedDays={progress.bookmarkedDays}
            preferredLanguage={preferredLanguage}
            onSelectDay={handleSelectDay}
            onToggleBookmark={handleToggleBookmark}
          />
        )}

        {currentTab === 'diagnostic' && (
          <DiagnosticModal
            preferredLanguage={preferredLanguage}
            onAssessmentComplete={handleAssessmentComplete}
            savedResult={progress.diagnosticResult}
            onClose={() => setCurrentTab('workspace')}
          />
        )}

        {currentTab === 'mocktest' && (
          <MockTestView
            preferredLanguage={preferredLanguage}
            onTestComplete={handleMockTestComplete}
            mockTestScores={progress.mockTestScores}
          />
        )}
      </main>

      {/* Floating AI Mentor Chat Trigger */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => {
            setChatInitialPrompt(undefined);
            setIsChatOpen(true);
          }}
          className="group flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white rounded-2xl shadow-xl shadow-blue-500/30 transition-all hover:scale-105 cursor-pointer font-bold text-xs"
        >
          <div className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-cyan-200" />
          </div>
          <div className="text-left">
            <span className="block font-black leading-tight">
              {progress.userProfile?.name ? 'Ask AI Mentor' : 'Chat with Guru'}
            </span>
            <span className="text-[10px] text-cyan-200 font-normal">
              24/7 Interactive AI Tutor
            </span>
          </div>
        </button>
      </div>

      {/* Conversational AI Mentor Drawer */}
      <ChatbotDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        preferredLanguage={preferredLanguage}
        currentDay={progress.currentDay}
        currentProblem={currentDayData}
        currentCode={currentSavedCode}
        userLevel={progress.assessedLevel}
        userProfile={progress.userProfile}
        initialPrompt={chatInitialPrompt}
      />

      {/* Student Onboarding & Profile Modal */}
      <OnboardingModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        preferredLanguage={preferredLanguage}
        currentProfile={progress.userProfile}
        onSaveProfile={handleSaveProfile}
        isInitialRequired={!progress.userProfile}
      />
    </div>
  );
}
