import React, { useState } from 'react';
import { DAYS_CURRICULUM, PHASES } from '../data/curriculum';
import { PreferredLanguage } from '../types';
import { CheckCircle2, Trophy, Search, Star } from 'lucide-react';

interface CurriculumRoadmapProps {
  currentDay: number;
  completedDays: number[];
  bookmarkedDays: number[];
  preferredLanguage?: PreferredLanguage;
  onSelectDay: (day: number) => void;
  onToggleBookmark: (day: number) => void;
}

export const CurriculumRoadmap: React.FC<CurriculumRoadmapProps> = ({
  currentDay,
  completedDays,
  bookmarkedDays,
  onSelectDay,
  onToggleBookmark,
}) => {
  const [selectedPhase, setSelectedPhase] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDays = DAYS_CURRICULUM.filter((item) => {
    const matchesPhase = selectedPhase === null || item.phase === selectedPhase;
    const matchesSearch =
      searchQuery === '' ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.day.toString() === searchQuery.trim();
    return matchesPhase && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 text-slate-100">
      {/* Roadmap Header & Stats */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 mb-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-black text-white flex items-center gap-2">
              <span>50-Day Curriculum Roadmap</span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
                {completedDays.length} / 50 Days Completed
              </span>
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Structured step-by-step curriculum organized into 5 phased milestones from core foundations to interview mastery.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search day or topic (e.g. Stack, Two Sum)..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Phase Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setSelectedPhase(null)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
              selectedPhase === null
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
            }`}
          >
            All Phases (Days 1 - 50)
          </button>
          {PHASES.map((p) => {
            const isSelected = selectedPhase === p.phase;
            return (
              <button
                key={p.phase}
                onClick={() => setSelectedPhase(p.phase)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>{p.name}</span>
                <span className="text-[11px] font-normal text-slate-400">({p.days})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of 50 Days */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3.5">
        {filteredDays.map((item) => {
          const isCompleted = completedDays.includes(item.day);
          const isCurrent = currentDay === item.day;
          const isBookmarked = bookmarkedDays.includes(item.day);

          let diffColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
          if (item.difficulty === 'Medium') diffColor = 'text-amber-400 bg-amber-500/10 border-amber-500/30';
          if (item.difficulty === 'Hard') diffColor = 'text-rose-400 bg-rose-500/10 border-rose-500/30';

          return (
            <div
              key={item.day}
              onClick={() => onSelectDay(item.day)}
              className={`group relative rounded-2xl p-4 transition-all cursor-pointer border flex flex-col justify-between ${
                isCurrent
                  ? 'bg-gradient-to-b from-blue-900/40 to-slate-900 border-cyan-400 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-400'
                  : isCompleted
                  ? 'bg-slate-900/60 border-emerald-500/40 hover:border-emerald-400/80'
                  : item.isMilestoneMockTest
                  ? 'bg-gradient-to-b from-purple-950/40 to-slate-900 border-purple-600/50 hover:border-purple-500'
                  : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`text-xs font-black px-2 py-0.5 rounded-lg ${
                        isCurrent
                          ? 'bg-cyan-500 text-slate-950'
                          : isCompleted
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      Day {item.day}
                    </span>
                    {item.isMilestoneMockTest && (
                      <span className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        <Trophy className="w-3 h-3 text-purple-300" />
                        <span>Mock Test</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleBookmark(item.day);
                      }}
                      className="p-1 text-slate-500 hover:text-amber-400 transition-colors"
                      title="Bookmark"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          isBookmarked ? 'text-amber-400 fill-amber-400' : ''
                        }`}
                      />
                    </button>
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : isCurrent ? (
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                    ) : null}
                  </div>
                </div>

                <h3 className="font-bold text-sm text-white line-clamp-1 group-hover:text-cyan-300 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-1">{item.topic}</p>
              </div>

              <div className="mt-4 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className={`px-2 py-0.5 rounded-md font-semibold border ${diffColor}`}>
                  {item.difficulty}
                </span>
                <span className="font-bold text-cyan-400">+{item.xpReward} XP</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
