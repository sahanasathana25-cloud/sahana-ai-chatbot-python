import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Award, CheckCircle, AlertCircle, ArrowRight, Brain, RotateCcw, Target, Sparkles, Check, X } from 'lucide-react';
import { DIAGNOSTIC_QUESTIONS } from '../data/diagnosticQuestions';
import { PreferredLanguage, UserLevel } from '../types';

interface DiagnosticModalProps {
  preferredLanguage?: PreferredLanguage;
  onAssessmentComplete: (result: {
    level: UserLevel;
    levelTitle: string;
    recommendedStartDay: number;
    scorePercent: number;
    categories: { logic: number; syntax: number; dataStructures: number; algorithms: number };
    summary: string;
  }) => void;
  onClose?: () => void;
  savedResult?: any;
}

export const DiagnosticModal: React.FC<DiagnosticModalProps> = ({
  onAssessmentComplete,
  onClose,
  savedResult,
}) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const [isCompleted, setIsCompleted] = useState(!!savedResult);
  const [evaluationResult, setEvaluationResult] = useState<any>(savedResult || null);

  const currentQ = DIAGNOSTIC_QUESTIONS[currentIdx];
  const totalQ = DIAGNOSTIC_QUESTIONS.length;
  const isLastQuestion = currentIdx === totalQ - 1;

  const handleSelectOption = (optionIdx: number) => {
    if (showExplanation) return;
    setSelectedAnswers((prev) => ({ ...prev, [currentIdx]: optionIdx }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    setShowExplanation(false);
    if (!isLastQuestion) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      finishAssessment();
    }
  };

  const finishAssessment = async () => {
    let correctCount = 0;
    const categoryTotals: Record<string, { correct: number; total: number }> = {
      logic: { correct: 0, total: 0 },
      syntax: { correct: 0, total: 0 },
      dataStructures: { correct: 0, total: 0 },
      algorithms: { correct: 0, total: 0 },
    };

    DIAGNOSTIC_QUESTIONS.forEach((q, i) => {
      const userAns = selectedAnswers[i];
      const isCorrect = userAns === q.correctIndex;
      if (isCorrect) correctCount++;
      if (categoryTotals[q.category]) {
        categoryTotals[q.category].total++;
        if (isCorrect) categoryTotals[q.category].correct++;
      }
    });

    const scorePercent = Math.round((correctCount / totalQ) * 100);

    let level: UserLevel = 'Beginner';
    let levelTitle = 'Beginner Explorer (Foundation Level)';
    let recommendedStartDay = 1;

    if (scorePercent >= 80) {
      level = 'Advanced';
      levelTitle = 'Advanced Problem Solver (Algorithm Level)';
      recommendedStartDay = 21;
    } else if (scorePercent >= 50) {
      level = 'Intermediate';
      levelTitle = 'Intermediate Builder (Data Structures Level)';
      recommendedStartDay = 11;
    }

    const categories = {
      logic: Math.round((categoryTotals.logic.correct / (categoryTotals.logic.total || 1)) * 100),
      syntax: Math.round((categoryTotals.syntax.correct / (categoryTotals.syntax.total || 1)) * 100),
      dataStructures: Math.round((categoryTotals.dataStructures.correct / (categoryTotals.dataStructures.total || 1)) * 100),
      algorithms: Math.round((categoryTotals.algorithms.correct / (categoryTotals.algorithms.total || 1)) * 100),
    };

    const summary = `Your diagnostic assessment score is ${scorePercent}%. You have been placed in the ${levelTitle} tier. Based on your skill evaluation, we recommend starting from Day ${recommendedStartDay} of your curriculum for optimal learning!`;

    const res = {
      level,
      levelTitle,
      recommendedStartDay,
      scorePercent,
      categories,
      summary,
    };

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // ignore
    }

    setEvaluationResult(res);
    setIsCompleted(true);
    onAssessmentComplete(res);
  };

  const restartQuiz = () => {
    setSelectedAnswers({});
    setCurrentIdx(0);
    setShowExplanation(false);
    setIsCompleted(false);
    setEvaluationResult(null);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-slate-900/60 border border-blue-800/40 rounded-2xl p-6 mb-8 relative overflow-hidden">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <span>Skill Level Diagnostic Assessment</span>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Placement Test
              </span>
            </h1>
            <p className="text-sm text-slate-300 mt-1">
              Answer 8 quick questions to benchmark your programming logic and discover your optimal starting day.
            </p>
          </div>
        </div>
      </div>

      {!isCompleted ? (
        /* Question Card */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
          {/* Progress Header */}
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Question {currentIdx + 1} of {totalQ}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 uppercase">
                {currentQ.category}
              </span>
            </div>
            <div className="w-32 bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-cyan-500 h-full transition-all duration-300"
                style={{ width: `${((currentIdx + 1) / totalQ) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Text */}
          <div className="mb-6">
            <h2 className="text-lg sm:text-xl font-bold text-white mb-2 leading-relaxed">
              {currentQ.question}
            </h2>
          </div>

          {/* Optional Code Snippet */}
          {currentQ.codeSnippet && (
            <div className="mb-6 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 p-4 font-mono text-xs sm:text-sm text-cyan-300">
              <pre className="overflow-x-auto">{currentQ.codeSnippet}</pre>
            </div>
          )}

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {currentQ.options.map((opt, i) => {
              const isSelected = selectedAnswers[currentIdx] === i;
              const isCorrect = i === currentQ.correctIndex;
              let btnClass = 'border-slate-800 bg-slate-800/40 hover:bg-slate-800/80 hover:border-slate-700 text-slate-200';

              if (showExplanation) {
                if (isCorrect) {
                  btnClass = 'border-emerald-500 bg-emerald-500/10 text-emerald-300 font-semibold';
                } else if (isSelected && !isCorrect) {
                  btnClass = 'border-rose-500 bg-rose-500/10 text-rose-300';
                }
              } else if (isSelected) {
                btnClass = 'border-cyan-500 bg-cyan-500/20 text-cyan-300';
              }

              return (
                <button
                  key={i}
                  disabled={showExplanation}
                  onClick={() => handleSelectOption(i)}
                  className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 cursor-pointer ${btnClass}`}
                >
                  <span className="w-6 h-6 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-sm leading-relaxed grow">{opt}</span>
                  {showExplanation && isCorrect && <Check className="w-5 h-5 text-emerald-400 shrink-0" />}
                  {showExplanation && isSelected && !isCorrect && <X className="w-5 h-5 text-rose-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {showExplanation && (
            <div className="mb-6 p-4 rounded-xl bg-slate-950/80 border border-slate-800 animate-fadeIn">
              <div className="flex items-center gap-2 mb-1 text-xs font-bold text-cyan-400 uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Explanation & Insight</span>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">{currentQ.explanation}</p>
            </div>
          )}

          {/* Navigation Footer */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <span className="text-xs text-slate-400">
              {showExplanation ? 'Click next to proceed' : 'Select an option to evaluate'}
            </span>
            {showExplanation && (
              <button
                onClick={handleNext}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <span>{isLastQuestion ? 'Complete Assessment' : 'Next Question'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Evaluation Results View */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl">
          <div className="text-center mb-8">
            <div className="inline-flex p-4 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30 mb-4 animate-bounce">
              <Award className="w-12 h-12" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              {evaluationResult?.levelTitle || 'Assessment Complete'}
            </h2>
            <p className="text-base text-cyan-400 font-semibold mt-1">
              Overall Diagnostic Score: {evaluationResult?.scorePercent}%
            </p>
            <p className="text-sm text-slate-300 max-w-xl mx-auto mt-2 leading-relaxed">
              {evaluationResult?.summary}
            </p>
          </div>

          {/* Recommended Starting Point Callout */}
          <div className="mb-8 p-5 rounded-2xl bg-gradient-to-r from-blue-950/70 to-indigo-950/70 border border-blue-700/50 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                Personalized Recommendation
              </span>
              <p className="text-base text-white font-bold">
                Recommended Start: Day {evaluationResult?.recommendedStartDay} (
                {evaluationResult?.level === 'Beginner'
                  ? 'Phase 1: Foundations & Logic'
                  : evaluationResult?.level === 'Intermediate'
                  ? 'Phase 2: Core Data Structures'
                  : 'Phase 3: Algorithms & Problem Solving'}
                )
              </p>
              <p className="text-xs text-slate-300 mt-0.5">
                Targeted pacing configured to build your confidence and interview problem-solving speed.
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold shrink-0 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
            >
              Go to Day {evaluationResult?.recommendedStartDay}
            </button>
          </div>

          {/* Skill Breakdown Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-medium block">Logic & Flow</span>
              <span className="text-xl font-black text-cyan-400 mt-1 block">
                {evaluationResult?.categories?.logic ?? 100}%
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-medium block">Syntax & Types</span>
              <span className="text-xl font-black text-blue-400 mt-1 block">
                {evaluationResult?.categories?.syntax ?? 100}%
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-medium block">Data Structures</span>
              <span className="text-xl font-black text-indigo-400 mt-1 block">
                {evaluationResult?.categories?.dataStructures ?? 100}%
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-medium block">Algorithms</span>
              <span className="text-xl font-black text-emerald-400 mt-1 block">
                {evaluationResult?.categories?.algorithms ?? 100}%
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={restartQuiz}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retake Assessment</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
