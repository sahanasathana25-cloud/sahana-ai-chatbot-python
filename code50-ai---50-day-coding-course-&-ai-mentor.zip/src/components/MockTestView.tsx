import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Timer,
  CheckCircle2,
  XCircle,
  Sparkles,
  RotateCcw,
  BookOpen,
  Award,
  Play,
} from 'lucide-react';
import { MILESTONE_TESTS, MilestoneMockTest } from '../data/mockTests';
import { PreferredLanguage } from '../types';

interface MockTestViewProps {
  preferredLanguage?: PreferredLanguage;
  onTestComplete: (day: number, score: number, xpReward: number) => void;
  mockTestScores: Record<number, number>;
}

export const MockTestView: React.FC<MockTestViewProps> = ({
  onTestComplete,
  mockTestScores,
}) => {
  const [activeDayTest, setActiveDayTest] = useState<number | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [isTestSubmitted, setIsTestSubmitted] = useState(false);
  const [testScore, setTestScore] = useState<number | null>(null);

  const [customTopic, setCustomTopic] = useState('');
  const [isGeneratingCustom, setIsGeneratingCustom] = useState(false);
  const [customTest, setCustomTest] = useState<MilestoneMockTest | null>(null);

  const selectedTest: MilestoneMockTest | undefined = customTest
    ? customTest
    : activeDayTest
    ? MILESTONE_TESTS[activeDayTest]
    : undefined;

  const handleStartTest = (day: number) => {
    setCustomTest(null);
    setActiveDayTest(day);
    setCurrentQIndex(0);
    setAnswers({});
    setIsTestSubmitted(false);
    setTestScore(null);
  };

  const handleSelectOption = (qIdx: number, optIdx: number) => {
    if (isTestSubmitted) return;
    setAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleSubmitTest = () => {
    if (!selectedTest) return;
    let correct = 0;
    selectedTest.questions.forEach((q, idx) => {
      if (answers[idx] === q.correctOptionIndex) {
        correct++;
      }
    });

    const finalScore = Math.round((correct / selectedTest.questions.length) * 100);
    setTestScore(finalScore);
    setIsTestSubmitted(true);

    const xpEarned = Math.round((finalScore / 100) * 150);
    onTestComplete(selectedTest.day, finalScore, xpEarned);

    if (finalScore >= selectedTest.passingScore) {
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // ignore
      }
    }
  };

  const handleGenerateCustomTest = async () => {
    if (!customTopic.trim() || isGeneratingCustom) return;
    setIsGeneratingCustom(true);
    try {
      const res = await fetch('/api/generate-mocktest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: customTopic,
          difficulty: 'Medium',
          preferredLanguage: 'english',
        }),
      });

      const data = await res.json();
      if (data && data.questions) {
        const formattedTest: MilestoneMockTest = {
          day: 99,
          title: `Custom Test: ${data.topic || customTopic}`,
          titleTamil: '',
          durationMinutes: 15,
          passingScore: 70,
          questions: data.questions.map((q: any) => ({
            id: q.id,
            question: q.question,
            questionTamil: '',
            codeSnippet: q.codeSnippet,
            options: q.options,
            correctOptionIndex: q.correctOptionIndex,
            explanation: q.explanation,
            explanationTamil: '',
          })),
        };

        setCustomTest(formattedTest);
        setActiveDayTest(99);
        setCurrentQIndex(0);
        setAnswers({});
        setIsTestSubmitted(false);
        setTestScore(null);
      }
    } catch (err) {
      console.error('Custom mock test error:', err);
    } finally {
      setIsGeneratingCustom(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 text-slate-100">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-950/40 via-indigo-950/40 to-slate-900 border border-purple-800/40 rounded-2xl p-6 mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              Milestone Mock Tests & Skill Assessments
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Rigorous assessments at each milestone (Day 10, Day 20, Day 30, Day 50) to evaluate retention, speed, and interview problem-solving readiness.
            </p>
          </div>
        </div>
      </div>

      {!selectedTest ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.values(MILESTONE_TESTS).map((test) => {
              const previousScore = mockTestScores[test.day];
              const isPassed = previousScore !== undefined && previousScore >= test.passingScore;

              return (
                <div
                  key={test.day}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-6 flex flex-col justify-between transition-all shadow-lg"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        Day {test.day} Milestone Test
                      </span>
                      {previousScore !== undefined && (
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            isPassed
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          Best Score: {previousScore}%
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-white mb-1">{test.title}</h3>

                    <div className="flex items-center gap-4 text-xs text-slate-400 mt-4">
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{test.questions.length} Questions</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Timer className="w-3.5 h-3.5 text-amber-400" />
                        <span>{test.durationMinutes} Minutes</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Pass: {test.passingScore}%</span>
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleStartTest(test.day)}
                    className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/30 transition-all cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>{previousScore !== undefined ? 'Retake Test' : 'Start Mock Test'}</span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* AI On-Demand Mock Test Generator */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base font-bold text-white">Generate Custom AI Mock Test</h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Practice any targeted topic such as "Sliding Window", "Time & Work", "Recursion", or "Binary Trees".
              Our AI Mentor will generate a 5-question test on demand.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <input
                type="text"
                value={customTopic}
                onChange={(e) => setCustomTopic(e.target.value)}
                placeholder="Enter topic (e.g. HashMaps & Stacks, Binary Search, Time & Distance)..."
                className="w-full sm:flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              <button
                onClick={handleGenerateCustomTest}
                disabled={isGeneratingCustom || !customTopic.trim()}
                className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-cyan-500/20 disabled:opacity-50 transition-all cursor-pointer shrink-0"
              >
                {isGeneratingCustom ? 'Generating Test...' : 'Generate with AI'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
            <div>
              <span className="text-xs font-bold text-purple-400 uppercase tracking-wider block">
                {selectedTest.title}
              </span>
              <p className="text-xs text-slate-400 mt-0.5">
                Answer all questions and submit to calculate your score.
              </p>
            </div>
            <button
              onClick={() => setActiveDayTest(null)}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 cursor-pointer"
            >
              Exit Test
            </button>
          </div>

          {!isTestSubmitted ? (
            <div className="space-y-8">
              {selectedTest.questions.map((q, qIdx) => (
                <div key={q.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-start gap-3 mb-3">
                    <span className="w-6 h-6 rounded-lg bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                      {qIdx + 1}
                    </span>
                    <h4 className="text-sm sm:text-base font-bold text-white leading-relaxed">
                      {q.question}
                    </h4>
                  </div>

                  {q.codeSnippet && (
                    <pre className="mb-4 p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-cyan-300 overflow-x-auto">
                      {q.codeSnippet}
                    </pre>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = answers[qIdx] === optIdx;
                      return (
                        <button
                          key={optIdx}
                          onClick={() => handleSelectOption(qIdx, optIdx)}
                          className={`p-3.5 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-3 cursor-pointer ${
                            isSelected
                              ? 'border-cyan-500 bg-cyan-500/20 text-cyan-200'
                              : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                          }`}
                        >
                          <span className="w-5 h-5 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold shrink-0">
                            {String.fromCharCode(65 + optIdx)}
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div className="flex justify-end pt-4 border-t border-slate-800">
                <button
                  onClick={handleSubmitTest}
                  disabled={Object.keys(answers).length === 0}
                  className="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50"
                >
                  Submit & Calculate Score
                </button>
              </div>
            </div>
          ) : (
            <div>
              <div className="text-center p-6 bg-slate-950 rounded-2xl border border-slate-800 mb-8">
                <div className="inline-flex p-3 rounded-2xl bg-purple-500/20 text-purple-300 mb-3">
                  <Trophy className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-black text-white">
                  Test Score: {testScore}%
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Passing Score: {selectedTest.passingScore}% •{' '}
                  <span className={testScore! >= selectedTest.passingScore ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {testScore! >= selectedTest.passingScore ? 'PASSED' : 'NEEDS PRACTICE'}
                  </span>
                </p>
              </div>

              <div className="space-y-6">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Question Review & Explanations
                </h4>
                {selectedTest.questions.map((q, idx) => {
                  const userAns = answers[idx];
                  const isCorrect = userAns === q.correctOptionIndex;

                  return (
                    <div
                      key={q.id}
                      className={`p-4 rounded-xl border ${
                        isCorrect
                          ? 'bg-emerald-950/20 border-emerald-800/40'
                          : 'bg-rose-950/20 border-rose-800/40'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="text-xs font-bold text-white">
                          Question {idx + 1}: {q.question}
                        </span>
                        {isCorrect ? (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Correct
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-rose-400">
                            <XCircle className="w-3.5 h-3.5" /> Incorrect
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-300 space-y-1 mb-2 font-mono">
                        <div>
                          Your answer: <span className={isCorrect ? 'text-emerald-300' : 'text-rose-400'}>{q.options[userAns] || 'None'}</span>
                        </div>
                        {!isCorrect && (
                          <div>
                            Correct answer: <span className="text-emerald-400">{q.options[q.correctOptionIndex]}</span>
                          </div>
                        )}
                      </div>

                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300">
                        <span className="font-bold text-cyan-400 block mb-0.5">Explanation:</span>
                        {q.explanation}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-center gap-4 mt-8">
                <button
                  onClick={() => handleStartTest(selectedTest.day)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Test</span>
                </button>
                <button
                  onClick={() => setActiveDayTest(null)}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
                >
                  Back to Tests List
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
