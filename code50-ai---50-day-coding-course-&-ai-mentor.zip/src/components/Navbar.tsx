import React from 'react';
import {
  Flame,
  Trophy,
  Code2,
  Compass,
  Award,
  User,
  Calculator,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { PreferredLanguage, UserLevel, UserProfile, CourseTrackId } from '../types';

interface NavbarProps {
  currentTab: 'workspace' | 'roadmap' | 'diagnostic' | 'mocktest';
  setCurrentTab: (tab: 'workspace' | 'roadmap' | 'diagnostic' | 'mocktest') => void;
  preferredLanguage: PreferredLanguage;
  setPreferredLanguage: (lang: PreferredLanguage) => void;
  completedCount: number;
  currentDay: number;
  streak: number;
  totalXp: number;
  assessedLevel: UserLevel | null;
  userProfile: UserProfile | null;
  onOpenProfile: () => void;
  onOpenChat: () => void;
  onResetProgress: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  completedCount,
  currentDay,
  streak,
  totalXp,
  assessedLevel,
  userProfile,
  onOpenProfile,
  onOpenChat,
}) => {
  const percentComplete = Math.round((completedCount / 50) * 100);

  const getCourseShortBadge = (id?: CourseTrackId) => {
    switch (id) {
      case 'aptitude':
        return 'Aptitude 50';
      case 'coding_combo':
        return 'Tech + Aptitude';
      case 'python_dsa':
        return 'Python DSA';
      case 'javascript_dsa':
        return 'JavaScript Web';
      case 'java_dsa':
        return 'Java Placement';
      default:
        return '50-Day Course';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Course Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              {userProfile?.selectedCourse === 'aptitude' ? (
                <Calculator className="w-6 h-6 text-white" />
              ) : (
                <Code2 className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300 bg-clip-text text-transparent">
                  Code50 AI
                </span>
                <button
                  onClick={onOpenProfile}
                  className="flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 hover:bg-cyan-900 transition-colors cursor-pointer"
                  title="Click to switch course or edit details"
                >
                  <span>{getCourseShortBadge(userProfile?.selectedCourse)}</span>
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {userProfile
                  ? `Welcome, ${userProfile.name} • ${userProfile.targetGoal}`
                  : '50-Day Bootcamp & Interactive AI Mentor'}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/70 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setCurrentTab('workspace')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                currentTab === 'workspace'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Day {currentDay} Challenge</span>
            </button>
            <button
              onClick={() => setCurrentTab('roadmap')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                currentTab === 'roadmap'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span>50-Day Roadmap</span>
            </button>
            <button
              onClick={() => setCurrentTab('diagnostic')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                currentTab === 'diagnostic'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Award className="w-4 h-4 text-amber-400" />
              <span>Level Assessment {assessedLevel ? `(${assessedLevel})` : ''}</span>
            </button>
            <button
              onClick={() => setCurrentTab('mocktest')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                currentTab === 'mocktest'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Trophy className="w-4 h-4 text-emerald-400" />
              <span>Mock Tests</span>
            </button>
          </nav>

          {/* Right Controls: Profile Avatar, Stats & AI Guru */}
          <div className="flex items-center gap-3">
            {/* Student Profile Pill */}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all text-xs cursor-pointer"
              title="Click to view/edit profile or change course"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-500 flex items-center justify-center text-[10px] font-black text-slate-950">
                {userProfile?.name ? userProfile.name.charAt(0).toUpperCase() : <User className="w-3 h-3" />}
              </div>
              <span className="font-bold text-slate-200 hidden sm:inline max-w-[100px] truncate">
                {userProfile?.name || 'Student Profile'}
              </span>
            </button>

            {/* Streak & XP */}
            <div className="flex items-center gap-1.5">
              <div
                className="flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-400 text-xs font-bold"
                title="Daily streak counter"
              >
                <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>{streak}d</span>
              </div>
              <div
                className="flex items-center gap-1 px-2.5 py-1 bg-cyan-500/10 border border-cyan-500/20 rounded-lg text-cyan-400 text-xs font-bold"
                title="Total XP points earned"
              >
                <Trophy className="w-3.5 h-3.5 text-cyan-400" />
                <span>{totalXp} XP</span>
              </div>
            </div>

            {/* Chatbot Trigger */}
            <button
              onClick={onOpenChat}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/30 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
              <span>AI Mentor</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800 text-xs font-medium">
          <button
            onClick={() => setCurrentTab('workspace')}
            className={`px-2 py-1 rounded cursor-pointer ${currentTab === 'workspace' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
          >
            Day {currentDay}
          </button>
          <button
            onClick={() => setCurrentTab('roadmap')}
            className={`px-2 py-1 rounded cursor-pointer ${currentTab === 'roadmap' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
          >
            Roadmap
          </button>
          <button
            onClick={() => setCurrentTab('diagnostic')}
            className={`px-2 py-1 rounded cursor-pointer ${currentTab === 'diagnostic' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Level Test
          </button>
          <button
            onClick={() => setCurrentTab('mocktest')}
            className={`px-2 py-1 rounded cursor-pointer ${currentTab === 'mocktest' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            Mock Tests
          </button>
        </div>
      </div>

      {/* Progress Line */}
      <div className="w-full bg-slate-800 h-1">
        <div
          className="bg-gradient-to-r from-cyan-400 to-blue-600 h-1 transition-all duration-500"
          style={{ width: `${Math.max(percentComplete, 2)}%` }}
        />
      </div>
    </header>
  );
};
