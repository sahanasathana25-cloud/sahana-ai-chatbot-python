import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  BookOpen,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  X,
  Target,
  GraduationCap,
  Calculator,
  Terminal,
  Code,
  Cpu,
} from 'lucide-react';
import { COURSE_TRACKS } from '../data/courses';
import { UserProfile, CourseTrackId, PreferredLanguage } from '../types';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose?: () => void;
  preferredLanguage: PreferredLanguage;
  currentProfile: UserProfile | null;
  onSaveProfile: (profile: UserProfile) => void;
  isInitialRequired?: boolean;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onSaveProfile,
  isInitialRequired = false,
}) => {
  const [name, setName] = useState(currentProfile?.name || '');
  const [email, setEmail] = useState(currentProfile?.email || 'sahanasathana25@gmail.com');
  const [mobile, setMobile] = useState(currentProfile?.mobile || '');
  const [selectedCourse, setSelectedCourse] = useState<CourseTrackId>(
    currentProfile?.selectedCourse || 'aptitude'
  );
  const [targetGoal, setTargetGoal] = useState(
    currentProfile?.targetGoal || 'Campus Placements'
  );
  const [errors, setErrors] = useState<{ name?: string; email?: string; mobile?: string }>({});

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: { name?: string; email?: string; mobile?: string } = {};
    if (!name.trim()) newErrors.name = 'Please enter your full name';
    if (!email.trim() || !email.includes('@')) newErrors.email = 'Please enter a valid email address';
    if (!mobile.trim() || mobile.replace(/\D/g, '').length < 10) {
      newErrors.mobile = 'Please enter a valid 10-digit mobile number';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const profile: UserProfile = {
      name: name.trim(),
      email: email.trim(),
      mobile: mobile.trim(),
      selectedCourse,
      targetGoal,
      registeredAt: currentProfile?.registeredAt || new Date().toISOString(),
    };

    onSaveProfile(profile);
    if (onClose) onClose();
  };

  const getCourseIcon = (id: CourseTrackId) => {
    switch (id) {
      case 'aptitude':
        return <Calculator className="w-5 h-5 text-amber-400" />;
      case 'coding_combo':
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'python_dsa':
        return <Terminal className="w-5 h-5 text-blue-400" />;
      case 'javascript_dsa':
        return <Code className="w-5 h-5 text-yellow-400" />;
      case 'java_dsa':
        return <Cpu className="w-5 h-5 text-rose-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
        {/* Close Button if not initial required */}
        {!isInitialRequired && onClose && (
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <span>{currentProfile ? 'Update Student Profile' : 'Student Registration'}</span>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                50-Day Curriculum
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Enter your student details and select your 50-day learning curriculum.
            </p>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* User Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Full Name *</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sahana"
                className={`w-full bg-slate-950 border rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                  errors.name ? 'border-rose-500' : 'border-slate-800 focus:border-cyan-500'
                }`}
              />
              {errors.name && <p className="text-[11px] text-rose-400 mt-1">{errors.name}</p>}
            </div>

            {/* Email Address */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-cyan-400" />
                <span>Email Address *</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@gmail.com"
                className={`w-full bg-slate-950 border rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                  errors.email ? 'border-rose-500' : 'border-slate-800 focus:border-cyan-500'
                }`}
              />
              {errors.email && <p className="text-[11px] text-rose-400 mt-1">{errors.email}</p>}
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Mobile Number *</span>
              </label>
              <input
                type="tel"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="e.g. 9876543210"
                className={`w-full bg-slate-950 border rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all ${
                  errors.mobile ? 'border-rose-500' : 'border-slate-800 focus:border-cyan-500'
                }`}
              />
              {errors.mobile && <p className="text-[11px] text-rose-400 mt-1">{errors.mobile}</p>}
            </div>
          </div>

          {/* Goal Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-cyan-400" />
              <span>Target Career Goal</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                'Campus Placements 2026/2027',
                'Top IT MNCs (TCS, Infosys, Zoho, Cognizant)',
                'Software Development Engineer (Product Companies)',
                'Aptitude & General Competitive Assessments',
              ].map((goal) => (
                <button
                  type="button"
                  key={goal}
                  onClick={() => setTargetGoal(goal)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                    targetGoal === goal
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {goal}
                </button>
              ))}
            </div>
          </div>

          {/* Course Selection Cards */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>Select Your 50-Day Course Track *</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[300px] overflow-y-auto pr-1">
              {COURSE_TRACKS.map((course) => {
                const isSelected = selectedCourse === course.id;
                return (
                  <div
                    key={course.id}
                    onClick={() => setSelectedCourse(course.id)}
                    className={`relative p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-gradient-to-br from-cyan-950/60 to-slate-900 border-cyan-400 ring-1 ring-cyan-400 shadow-lg shadow-cyan-500/10'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700">
                            {getCourseIcon(course.id)}
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-slate-700">
                            {course.badge}
                          </span>
                        </div>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                      </div>

                      <h4 className="text-sm font-bold text-white mb-0.5">{course.name}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mt-1">
                        {course.description}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <span>50-Day Curriculum</span>
                      <span className="text-cyan-400 font-semibold">Mock Tests Included</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            {!isInitialRequired && onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <span>{currentProfile ? 'Save & Start Learning' : 'Confirm & Start 50-Day Course'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
