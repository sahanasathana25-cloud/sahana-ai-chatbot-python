import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Play,
  Send,
  Lightbulb,
  CheckCircle2,
  XCircle,
  Copy,
  RotateCcw,
  Sparkles,
  BookOpen,
  Code2,
  ChevronRight,
  Calculator,
} from 'lucide-react';
import { DayCurriculum, LanguageKey, PreferredLanguage, CodeEvaluationResult } from '../types';
import { executeJavaScriptInBrowser, evaluateCodeRemotely } from '../utils/codeRunner';

interface ProblemWorkspaceProps {
  dayData: DayCurriculum;
  preferredLanguage?: PreferredLanguage;
  savedCode?: string;
  isCompleted: boolean;
  onCodeChange: (code: string) => void;
  onDayCompleted: (day: number, xp: number) => void;
  onOpenChatWithPrompt: (prompt: string, codeSnippet?: string) => void;
  onNextDay: () => void;
}

export const ProblemWorkspace: React.FC<ProblemWorkspaceProps> = ({
  dayData,
  savedCode,
  isCompleted,
  onCodeChange,
  onDayCompleted,
  onOpenChatWithPrompt,
  onNextDay,
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageKey>('javascript');
  const [code, setCode] = useState<string>(
    savedCode || dayData.starterCode.javascript
  );
  const [activeLeftTab, setActiveLeftTab] = useState<'problem' | 'notes' | 'hints'>('problem');
  const [unlockedHintLevel, setUnlockedHintLevel] = useState<number>(0);

  // Execution states
  const [isRunning, setIsRunning] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [testResults, setTestResults] = useState<
    { id: string; input: string; expected: string; actual: string; passed: boolean; logs?: string[]; error?: string }[]
  >([]);
  const [aiEvaluation, setAiEvaluation] = useState<CodeEvaluationResult | null>(null);
  const [activeBottomTab, setActiveBottomTab] = useState<'tests' | 'aiFeedback' | 'console'>('tests');
  const [consoleLogs, setConsoleLogs] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (savedCode) {
      setCode(savedCode);
    } else {
      setCode(dayData.starterCode[selectedLanguage]);
    }
    setTestResults([]);
    setAiEvaluation(null);
    setUnlockedHintLevel(0);
    setConsoleLogs([]);
  }, [dayData.day, selectedLanguage]);

  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    onCodeChange(newCode);
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setActiveBottomTab('tests');
    const allLogs: string[] = [];

    if (selectedLanguage === 'javascript') {
      const results = dayData.testCases.map((tc) => {
        const res = executeJavaScriptInBrowser(code, tc);
        if (res.logs && res.logs.length > 0) {
          allLogs.push(`[${tc.id}] ${res.logs.join(' | ')}`);
        }
        return {
          id: tc.id,
          input: tc.input,
          expected: tc.expectedOutput,
          actual: res.actual,
          passed: res.passed,
          error: res.error,
        };
      });

      setTestResults(results);
      setConsoleLogs(allLogs);
      setIsRunning(false);

      const allPassed = results.every((r) => r.passed);
      if (allPassed && !isCompleted) {
        celebrateSuccess();
        onDayCompleted(dayData.day, dayData.xpReward);
      }
    } else {
      handleSubmitWithAi();
    }
  };

  const handleSubmitWithAi = async () => {
    setIsEvaluating(true);
    setActiveBottomTab('aiFeedback');
    try {
      const evaluation = await evaluateCodeRemotely(
        {
          title: dayData.title,
          description: dayData.description.english,
          difficulty: dayData.difficulty,
          constraints: dayData.timeComplexity,
        },
        code,
        selectedLanguage,
        'english',
        dayData.testCases
      );

      setAiEvaluation(evaluation);

      if (evaluation.testResults) {
        setTestResults(
          evaluation.testResults.map((tr, i) => ({
            id: `test-${i + 1}`,
            input: tr.input,
            expected: tr.expected,
            actual: tr.actual,
            passed: tr.passed,
          }))
        );
      }

      if (evaluation.overallStatus === 'passed' && !isCompleted) {
        celebrateSuccess();
        onDayCompleted(dayData.day, dayData.xpReward);
      }
    } catch (err: any) {
      console.error('AI submit error:', err);
      setActiveBottomTab('tests');
    } finally {
      setIsEvaluating(false);
      setIsRunning(false);
    }
  };

  const celebrateSuccess = () => {
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // ignore
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleResetCode = () => {
    const starter = dayData.starterCode[selectedLanguage];
    setCode(starter);
    onCodeChange(starter);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = e.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const val = textarea.value;
      const newVal = val.substring(0, start) + '  ' + val.substring(end);
      handleCodeChange(newVal);
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      }, 0);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 text-slate-100 flex flex-col gap-6">
      {/* Top Banner / Day Metadata */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex flex-col items-center justify-center font-black text-white shrink-0 shadow-lg shadow-blue-500/20">
            <span className="text-[10px] uppercase font-bold tracking-wider text-blue-200">Day</span>
            <span className="text-lg leading-none">{dayData.day}</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 font-semibold uppercase">
                {dayData.phaseName}
              </span>
              <span
                className={`text-xs px-2 py-0.5 rounded font-bold ${
                  dayData.difficulty === 'Easy'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : dayData.difficulty === 'Medium'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                }`}
              >
                {dayData.difficulty}
              </span>
              {isCompleted && (
                <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Completed</span>
                </span>
              )}
            </div>
            <h1 className="text-lg sm:text-xl font-bold text-white mt-1">{dayData.title}</h1>
            <p className="text-xs text-slate-400 font-medium">{dayData.topic}</p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3 self-end md:self-auto">
          <div className="text-right hidden sm:block">
            <span className="text-xs text-slate-400 block font-medium">Reward Points</span>
            <span className="text-sm font-extrabold text-cyan-400">+{dayData.xpReward} XP</span>
          </div>
          {dayData.day < 50 && (
            <button
              onClick={onNextDay}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
            >
              <span>Next Day</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Problem, Theory & Hints */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[700px] overflow-hidden shadow-xl">
          {/* Tabs */}
          <div className="flex items-center border-b border-slate-800 bg-slate-950/60 px-4 pt-3 gap-2">
            <button
              onClick={() => setActiveLeftTab('problem')}
              className={`flex items-center gap-1.5 pb-3 px-2 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                activeLeftTab === 'problem'
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Problem</span>
            </button>
            <button
              onClick={() => setActiveLeftTab('notes')}
              className={`flex items-center gap-1.5 pb-3 px-2 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                activeLeftTab === 'notes'
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Theory & Notes</span>
            </button>
            <button
              onClick={() => setActiveLeftTab('hints')}
              className={`flex items-center gap-1.5 pb-3 px-2 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                activeLeftTab === 'hints'
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>Hints ({unlockedHintLevel}/3)</span>
            </button>
          </div>

          {/* Tab Content Area */}
          <div className="p-5 overflow-y-auto grow space-y-5 text-sm leading-relaxed">
            {activeLeftTab === 'problem' && (
              <>
                {/* Description */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                    {dayData.isAptitude ? 'Aptitude Challenge & Question' : 'Problem Statement'}
                  </h3>
                  <p className="text-slate-200">{dayData.description.english}</p>
                </div>

                {/* Aptitude Formula & Shortcut Card if available */}
                {dayData.formulaOrShortcut && (
                  <div className="p-4 rounded-xl bg-gradient-to-br from-amber-950/30 to-orange-950/20 border border-amber-600/40 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                      <Calculator className="w-4 h-4 text-amber-400" />
                      <span>Formula & Fast Shortcut Trick</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-amber-300">
                      {dayData.formulaOrShortcut.formula}
                    </div>
                    <p className="text-xs text-slate-300">
                      <strong className="text-amber-400">Shortcut: </strong>
                      {dayData.formulaOrShortcut.shortcutTrick}
                    </p>
                  </div>
                )}

                {/* Real World Analogy */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Real-World Analogy</span>
                  </div>
                  <p className="text-xs text-slate-300">{dayData.realWorldAnalogy.english}</p>
                </div>

                {/* Example Test Cases */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Sample Test Cases
                  </h3>
                  <div className="space-y-2">
                    {dayData.testCases.map((tc) => (
                      <div
                        key={tc.id}
                        className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs"
                      >
                        <div className="text-slate-400">
                          <span className="text-cyan-400 font-bold">Input:</span> {tc.input}
                        </div>
                        <div className="text-slate-300 mt-1">
                          <span className="text-emerald-400 font-bold">Output:</span> {tc.expectedOutput}
                        </div>
                        {tc.explanation && (
                          <div className="text-[11px] text-slate-400 mt-1 font-sans">
                            Note: {tc.explanation}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Target Complexity */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-400 block font-medium">Target Time:</span>
                    <span className="text-cyan-300 font-bold font-mono">{dayData.timeComplexity}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Target Space:</span>
                    <span className="text-cyan-300 font-bold font-mono">{dayData.spaceComplexity}</span>
                  </div>
                </div>
              </>
            )}

            {activeLeftTab === 'notes' && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <h3 className="text-sm font-bold text-white mb-2">Key Concept & Logic</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{dayData.conceptNotes.english}</p>
                </div>

                <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-900/40">
                  <h4 className="text-xs font-bold text-blue-300 uppercase tracking-wider mb-2">
                    Interview Application
                  </h4>
                  <p className="text-xs text-slate-300">
                    Interviewers test this problem to assess whether you jump straight to quadratic brute force
                    or recognize mathematical patterns that achieve linear or logarithmic time.
                  </p>
                </div>

                <button
                  onClick={() =>
                    onOpenChatWithPrompt(
                      `Please explain the core intuition and step-by-step logic behind "${dayData.title}" using a practical example.`
                    )
                  }
                  className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-xs font-bold transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Ask AI Mentor to Explain This Topic</span>
                </button>
              </div>
            )}

            {activeLeftTab === 'hints' && (
              <div className="space-y-4">
                {/* Level 1 Hint */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span>Hint 1: Direction & Clue</span>
                    </span>
                    {unlockedHintLevel < 1 && (
                      <button
                        onClick={() => setUnlockedHintLevel(1)}
                        className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold cursor-pointer"
                      >
                        Unlock
                      </button>
                    )}
                  </div>
                  {unlockedHintLevel >= 1 ? (
                    <p className="text-xs text-slate-300">{dayData.hints.level1}</p>
                  ) : (
                    <p className="text-xs text-slate-400 italic">Locked. Click unlock to view Hint 1.</p>
                  )}
                </div>

                {/* Level 2 Hint */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span>Hint 2: Pseudo-Code & Steps</span>
                    </span>
                    {unlockedHintLevel < 2 && (
                      <button
                        onClick={() => setUnlockedHintLevel(2)}
                        className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold cursor-pointer"
                      >
                        Unlock
                      </button>
                    )}
                  </div>
                  {unlockedHintLevel >= 2 ? (
                    <p className="text-xs text-slate-300">{dayData.hints.level2}</p>
                  ) : (
                    <p className="text-xs text-slate-400 italic">Locked. Try solving first before unlocking.</p>
                  )}
                </div>

                {/* Level 3 Solution */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Hint 3: Optimal Solution & Code Breakdown</span>
                    </span>
                    {unlockedHintLevel < 3 && (
                      <button
                        onClick={() => setUnlockedHintLevel(3)}
                        className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold cursor-pointer"
                      >
                        Reveal Solution
                      </button>
                    )}
                  </div>
                  {unlockedHintLevel >= 3 ? (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-300">{dayData.hints.solutionExplained}</p>
                      <pre className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-cyan-300 overflow-x-auto">
                        {dayData.optimalSolution[selectedLanguage]}
                      </pre>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 italic">
                      Solution code hidden. Solve it yourself for maximum learning!
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Code Editor & Test Runner */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[460px]">
            {/* Editor Toolbar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">Language:</span>
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value as LanguageKey)}
                  className="bg-slate-800 border border-slate-700 text-xs font-semibold text-cyan-300 rounded-lg px-2.5 py-1 focus:outline-none cursor-pointer"
                >
                  <option value="javascript">JavaScript (Live In-Browser)</option>
                  <option value="python">Python 3 (AI Judge)</option>
                  <option value="java">Java (AI Judge)</option>
                  <option value="cpp">C++ (AI Judge)</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
                  title="Copy Code"
                >
                  {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
                <button
                  onClick={handleResetCode}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
                  title="Reset to Template"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Code Textarea */}
            <div className="relative grow bg-[#0d1117] flex overflow-hidden">
              <textarea
                value={code}
                onChange={(e) => handleCodeChange(e.target.value)}
                onKeyDown={handleKeyDown}
                spellCheck={false}
                className="w-full h-full p-4 font-mono text-xs sm:text-sm text-cyan-200 bg-transparent resize-none focus:outline-none leading-relaxed selection:bg-cyan-500/30"
                placeholder="// Write your solution here..."
              />
            </div>

            {/* Action Bar Footer */}
            <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() =>
                  onOpenChatWithPrompt(
                    `Please review my solution for Day ${dayData.day} "${dayData.title}". Does it handle edge cases and optimal complexity?\n\`\`\`${selectedLanguage}\n${code}\n\`\`\``
                  )
                }
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Ask AI Mentor to Review</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunCode}
                  disabled={isRunning || isEvaluating}
                  className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                  <span>{isRunning ? 'Running...' : 'Run Code'}</span>
                </button>

                <button
                  onClick={handleSubmitWithAi}
                  disabled={isRunning || isEvaluating}
                  className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isEvaluating ? 'Evaluating...' : 'Submit & AI Judge'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Test Results & AI Feedback Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl min-h-[220px]">
            <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/80 px-4 pt-2.5">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveBottomTab('tests')}
                  className={`pb-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                    activeBottomTab === 'tests'
                      ? 'border-cyan-400 text-cyan-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Test Results ({testResults.filter((t) => t.passed).length}/{dayData.testCases.length})
                </button>
                <button
                  onClick={() => setActiveBottomTab('aiFeedback')}
                  className={`flex items-center gap-1 pb-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                    activeBottomTab === 'aiFeedback'
                      ? 'border-cyan-400 text-cyan-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>AI Mentor Evaluation</span>
                </button>
                <button
                  onClick={() => setActiveBottomTab('console')}
                  className={`pb-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                    activeBottomTab === 'console'
                      ? 'border-cyan-400 text-cyan-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Console Output
                </button>
              </div>

              {testResults.length > 0 && (
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    testResults.every((t) => t.passed)
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-rose-500/20 text-rose-300'
                  }`}
                >
                  {testResults.every((t) => t.passed) ? 'All Passed' : 'Some Tests Failed'}
                </span>
              )}
            </div>

            <div className="p-4 text-xs font-mono">
              {activeBottomTab === 'tests' && (
                <div>
                  {testResults.length === 0 ? (
                    <div className="text-slate-500 font-sans text-center py-6">
                      Click <strong className="text-slate-300">Run Code</strong> or{' '}
                      <strong className="text-cyan-400">Submit & AI Judge</strong> to evaluate your solution.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {testResults.map((t, idx) => (
                        <div
                          key={t.id}
                          className={`p-3 rounded-xl border flex flex-col gap-1.5 ${
                            t.passed
                              ? 'bg-emerald-950/20 border-emerald-800/40'
                              : 'bg-rose-950/20 border-rose-800/40'
                          }`}
                        >
                          <div className="flex items-center justify-between font-sans">
                            <span className="font-bold flex items-center gap-1.5">
                              {t.passed ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              ) : (
                                <XCircle className="w-4 h-4 text-rose-400" />
                              )}
                              <span className={t.passed ? 'text-emerald-300' : 'text-rose-300'}>
                                Test Case {idx + 1}
                              </span>
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {t.passed ? 'PASSED' : 'FAILED'}
                            </span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                            <div>
                              <span className="text-slate-500 block">Input:</span>
                              <span className="text-cyan-200">{t.input}</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block">Expected:</span>
                              <span className="text-emerald-300">{t.expected}</span>
                            </div>
                          </div>

                          {!t.passed && (
                            <div className="mt-1 pt-1 border-t border-rose-900/30 text-[11px] text-rose-300">
                              <span className="text-rose-400 font-bold">Actual Output:</span> {t.actual}
                              {t.error && <p className="text-rose-400 mt-0.5">{t.error}</p>}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeBottomTab === 'aiFeedback' && (
                <div className="font-sans">
                  {isEvaluating ? (
                    <div className="py-8 text-center text-slate-400 space-y-2">
                      <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto" />
                      <p className="text-xs">AI Mentor is analyzing time complexity & edge cases...</p>
                    </div>
                  ) : aiEvaluation ? (
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800">
                        <div className="flex items-center gap-3">
                          <div>
                            <span className="text-[10px] text-slate-400 block">Time Complexity:</span>
                            <span className="text-cyan-300 font-bold font-mono">
                              {aiEvaluation.timeComplexity}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block">Space Complexity:</span>
                            <span className="text-cyan-300 font-bold font-mono">
                              {aiEvaluation.spaceComplexity}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">Correctness Score:</span>
                          <span className="text-emerald-400 font-bold">{aiEvaluation.scorePercent}%</span>
                        </div>
                      </div>

                      <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-900/40 text-xs text-slate-200 leading-relaxed">
                        <span className="font-bold text-cyan-300 block mb-1">Mentor Feedback:</span>
                        {aiEvaluation.mentorFeedback}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {aiEvaluation.strengths && aiEvaluation.strengths.length > 0 && (
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                            <span className="font-bold text-emerald-400 block mb-1">Strengths</span>
                            <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                              {aiEvaluation.strengths.map((s, i) => (
                                <li key={i}>{s}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {aiEvaluation.improvements && aiEvaluation.improvements.length > 0 && (
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                            <span className="font-bold text-amber-400 block mb-1">Suggestions</span>
                            <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                              {aiEvaluation.improvements.map((s, i) => (
                                <li key={i}>{s}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-500 text-center py-6">
                      Click <strong className="text-cyan-400">Submit & AI Judge</strong> to receive
                      instant Big-O analysis and mentor guidance.
                    </div>
                  )}
                </div>
              )}

              {activeBottomTab === 'console' && (
                <div>
                  {consoleLogs.length === 0 ? (
                    <div className="text-slate-500 font-sans text-center py-6">
                      No console logs captured yet. Use <code className="text-cyan-400">console.log(...)</code> in your code to print outputs here.
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {consoleLogs.map((log, i) => (
                        <div key={i} className="text-cyan-300">
                          {log}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
