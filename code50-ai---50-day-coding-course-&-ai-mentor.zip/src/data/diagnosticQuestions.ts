import { DiagnosticQuestion } from '../types';

export const DIAGNOSTIC_QUESTIONS: DiagnosticQuestion[] = [
  {
    id: 'diag-1',
    question: 'What will be the output of this loop logic?',
    questionTamil: '',
    codeSnippet: `let count = 0;
for (let i = 1; i <= 4; i++) {
  count += i;
}
console.log(count);`,
    options: ['4', '10', '15', '0'],
    correctIndex: 1,
    category: 'logic',
    explanation: 'The loop adds 1 + 2 + 3 + 4, which equals 10.',
    explanationTamil: '',
  },
  {
    id: 'diag-2',
    question: 'Which data structure follows the LIFO (Last In First Out) principle?',
    questionTamil: '',
    options: ['Queue', 'Stack', 'Array', 'Linked List'],
    correctIndex: 1,
    category: 'dataStructures',
    explanation: 'Stack operates on the Last In, First Out (LIFO) principle, similar to a stack of trays.',
    explanationTamil: '',
  },
  {
    id: 'diag-3',
    question: 'What is the time complexity of Binary Search on a sorted array of size N?',
    questionTamil: '',
    options: ['O(N)', 'O(1)', 'O(log N)', 'O(N^2)'],
    correctIndex: 2,
    category: 'algorithms',
    explanation: 'Binary Search halves the search space in each iteration, resulting in O(log N) time complexity.',
    explanationTamil: '',
  },
  {
    id: 'diag-4',
    question: 'What does this conditional check evaluate to for n = 15?',
    questionTamil: '',
    codeSnippet: `if (n % 3 === 0 && n % 5 === 0) {
  console.log("FizzBuzz");
} else if (n % 3 === 0) {
  console.log("Fizz");
}`,
    options: ['Fizz', 'Buzz', 'FizzBuzz', 'Nothing'],
    correctIndex: 2,
    category: 'syntax',
    explanation: '15 is evenly divisible by both 3 and 5, so the first condition triggers and outputs "FizzBuzz".',
    explanationTamil: '',
  },
  {
    id: 'diag-5',
    question: 'What is the average time complexity of looking up a key in a Hash Map / Object?',
    questionTamil: '',
    options: ['O(1)', 'O(N)', 'O(log N)', 'O(N^2)'],
    correctIndex: 0,
    category: 'dataStructures',
    explanation: 'Hash maps compute memory locations using hash functions, providing constant O(1) average lookup time.',
    explanationTamil: '',
  },
  {
    id: 'diag-6',
    question: 'What happens when a recursive function lacks a base case?',
    questionTamil: '',
    options: ['Returns 0', 'Causes a Stack Overflow error', 'Executes once and terminates', 'Runs faster'],
    correctIndex: 1,
    category: 'logic',
    explanation: 'Without a terminating base case, recursive calls consume all available call stack memory, triggering a Stack Overflow error.',
    explanationTamil: '',
  },
  {
    id: 'diag-7',
    question: 'What is the Two-Pointer technique primarily suited for?',
    questionTamil: '',
    options: [
      'Traversing unordered cyclic graphs',
      'Scanning sorted arrays or checking palindromes in O(N) time and O(1) space',
      'Generating pseudo-random numbers',
      'Database schema migration',
    ],
    correctIndex: 1,
    category: 'algorithms',
    explanation: 'Two pointers traverse collections from opposite boundaries or sliding windows, avoiding quadratic nested loops.',
    explanationTamil: '',
  },
  {
    id: 'diag-8',
    question: 'What will this array manipulation code output?',
    questionTamil: '',
    codeSnippet: `const nums = [10, 20, 30];
nums.push(40);
nums.shift();
console.log(nums);`,
    options: ['[10, 20, 30, 40]', '[20, 30, 40]', '[10, 20, 30]', '[40, 30, 20]'],
    correctIndex: 1,
    category: 'syntax',
    explanation: 'push(40) appends 40 to the end, and shift() removes the first element (10), leaving [20, 30, 40].',
    explanationTamil: '',
  },
];
