export interface MockTestQuestion {
  id: string;
  question: string;
  questionTamil?: string;
  codeSnippet?: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  explanationTamil?: string;
}

export interface MilestoneMockTest {
  day: number;
  title: string;
  titleTamil?: string;
  durationMinutes: number;
  passingScore: number;
  questions: MockTestQuestion[];
}

export const MILESTONE_TESTS: Record<number, MilestoneMockTest> = {
  10: {
    day: 10,
    title: 'Phase 1 Milestone Assessment: Logic, Syntax & Loops',
    durationMinutes: 15,
    passingScore: 70,
    questions: [
      {
        id: 'm10-1',
        question: 'What is the value of `x` after: `let x = 5; x += x++` in JavaScript?',
        options: ['10', '11', '12', 'Error'],
        correctOptionIndex: 0,
        explanation: 'In JavaScript `x += x++` computes `5 + 5 = 10` before post-increment re-assignment.',
      },
      {
        id: 'm10-2',
        question: 'Which loop is guaranteed to execute its body at least once regardless of condition?',
        options: ['for loop', 'while loop', 'do...while loop', 'forEach loop'],
        correctOptionIndex: 2,
        explanation: 'A `do...while` loop checks its condition at the end of the iteration, guaranteeing at least one execution.',
      },
      {
        id: 'm10-3',
        question: 'How do you check if an integer `n` is odd without using the modulo operator `% 2`?',
        options: ['(n & 1) === 1', '(n | 1) === 0', '(n ^ 1) === 0', 'n >> 1 === 1'],
        correctOptionIndex: 0,
        explanation: 'Bitwise AND with 1 (`n & 1`) tests the least significant bit: 1 indicates an odd number, 0 an even number.',
      },
      {
        id: 'm10-4',
        question: 'What does `"hello".split("").reverse().join("")` evaluate to?',
        options: ['Capitalizes string', 'Reverses string to "olleh"', 'Sorts alphabetically', 'Counts characters'],
        correctOptionIndex: 1,
        explanation: 'Splits characters into an array, reverses the array, then joins them back into a reversed string.',
      },
      {
        id: 'm10-5',
        question: 'What is the time complexity of verifying a palindrome of length N using the two-pointer technique?',
        options: ['O(N^2)', 'O(N)', 'O(1)', 'O(log N)'],
        correctOptionIndex: 1,
        explanation: 'Each character is compared at most once, taking linear O(N) time with O(1) space.',
      },
    ],
  },
  20: {
    day: 20,
    title: 'Phase 2 Milestone Assessment: Hash Maps & Stacks',
    durationMinutes: 15,
    passingScore: 70,
    questions: [
      {
        id: 'm20-1',
        question: 'What occurs when two distinct keys generate the exact same hash code in a Hash Map?',
        options: ['Memory leak', 'Hash collision', 'Stack overflow', 'Segmentation fault'],
        correctOptionIndex: 1,
        explanation: 'A Hash collision occurs, which is resolved through techniques such as chaining or open addressing.',
      },
      {
        id: 'm20-2',
        question: 'What is the time complexity of push and pop operations in a standard Stack?',
        options: ['O(1)', 'O(N)', 'O(log N)', 'O(N^2)'],
        correctOptionIndex: 0,
        explanation: 'Stack operations at the top element take constant O(1) time.',
      },
      {
        id: 'm20-3',
        question: 'Why is the Two Sum problem faster when solved with a Hash Map compared to nested loops?',
        options: [
          'Hash Map uses less memory',
          'Hash Map complement lookup is O(1) instead of an O(N) scan, reducing total runtime from O(N^2) to O(N)',
          'Hash Map sorts the array in-place',
          'Nested loops cause stack overflow',
        ],
        correctOptionIndex: 1,
        explanation: 'Looking up the complement `target - x` takes O(1) average time in a Hash Map.',
      },
    ],
  },
  30: {
    day: 30,
    title: 'Phase 3 Milestone Assessment: Two Pointers & Binary Search',
    durationMinutes: 20,
    passingScore: 75,
    questions: [
      {
        id: 'm30-1',
        question: 'What condition is strictly MANDATORY before executing Binary Search?',
        options: [
          'Array must contain only positive integers',
          'Array elements must be sorted in monotonic order',
          'Array length must be an even number',
          'Array must not contain duplicate values',
        ],
        correctOptionIndex: 1,
        explanation: 'Binary search requires sorted data to determine whether to search the left or right sub-array.',
      },
      {
        id: 'm30-2',
        question: 'What problem does Kadane’s algorithm solve efficiently in O(N) time?',
        options: [
          'Sorting strings lexicographically',
          'Maximum Contiguous Subarray Sum',
          'Finding cycles in directed graphs',
          'Balancing a Binary Search Tree',
        ],
        correctOptionIndex: 1,
        explanation: 'Kadane’s algorithm determines the maximum sum of a contiguous subarray in linear O(N) time.',
      },
    ],
  },
  50: {
    day: 50,
    title: 'Grand Graduation Mock Test & Placement Certification',
    durationMinutes: 25,
    passingScore: 80,
    questions: [
      {
        id: 'm50-1',
        question: 'In systems design, which cache eviction policy removes the least recently accessed item first?',
        options: ['FIFO', 'LRU (Least Recently Used)', 'LFU (Least Frequently Used)', 'Random Eviction'],
        correctOptionIndex: 1,
        explanation: 'LRU tracks access order and evicts items that have not been read or written for the longest time.',
      },
      {
        id: 'm50-2',
        question: 'What is the time complexity of building a binary heap from an unsorted array of N elements?',
        options: ['O(N log N)', 'O(N)', 'O(1)', 'O(N^2)'],
        correctOptionIndex: 1,
        explanation: 'Using bottom-up heapify, a binary heap is built in linear O(N) time.',
      },
      {
        id: 'm50-3',
        question: 'What is the optimal approach for solving the Trapping Rain Water problem?',
        options: [
          'Two Pointers from both ends tracking maxLeft and maxRight in O(N) time and O(1) space',
          'Quadratic nested loops O(N^2)',
          'Recursive brute force O(2^N)',
          'Sorting the elevation height map',
        ],
        correctOptionIndex: 0,
        explanation: 'Two pointers moving inward with maxLeft and maxRight achieves O(N) time and O(1) space.',
      },
    ],
  },
};
