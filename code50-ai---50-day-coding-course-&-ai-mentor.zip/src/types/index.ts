export type LanguageKey = 'javascript' | 'python' | 'java' | 'cpp';

export type UserLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type PreferredLanguage = 'tanglish' | 'tamil' | 'english';

export type CourseTrackId =
  | 'aptitude'
  | 'coding_combo'
  | 'python_dsa'
  | 'javascript_dsa'
  | 'java_dsa';

export interface UserProfile {
  name: string;
  email: string;
  mobile: string;
  selectedCourse: CourseTrackId;
  targetGoal: string;
  registeredAt: string;
}

export interface CourseTrack {
  id: CourseTrackId;
  name: string;
  tamilName: string;
  tagline: string;
  description: string;
  iconName: string;
  badge: string;
  color: string;
  totalDays: number;
  topicsHighlight: string[];
}

export interface TestCase {
  id: string;
  input: string;
  expectedOutput: string;
  isHidden?: boolean;
  explanation?: string;
}

export interface DayCurriculum {
  day: number;
  phase: number;
  phaseName: string;
  phaseTamilName: string;
  title: string;
  titleTamil: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  xpReward: number;
  estimatedMins: number;
  isMilestoneMockTest?: boolean;
  isAptitude?: boolean;
  formulaOrShortcut?: {
    formula: string;
    tamilExplanation: string;
    shortcutTrick: string;
  };
  realWorldAnalogy: {
    english: string;
    tamil: string;
  };
  description: {
    english: string;
    tamil: string;
  };
  conceptNotes: {
    english: string;
    tamil: string;
  };
  starterCode: Record<LanguageKey, string>;
  testCases: TestCase[];
  hints: {
    level1: string;
    level2: string;
    solutionExplained: string;
  };
  optimalSolution: Record<LanguageKey, string>;
  timeComplexity: string;
  spaceComplexity: string;
}

export interface DiagnosticQuestion {
  id: string;
  question: string;
  questionTamil: string;
  codeSnippet?: string;
  options: string[];
  correctIndex: number;
  category: 'logic' | 'syntax' | 'dataStructures' | 'algorithms';
  explanation: string;
  explanationTamil: string;
}

export interface UserProgress {
  userProfile: UserProfile | null;
  completedDays: number[];
  currentDay: number;
  streak: number;
  lastActiveDate: string;
  totalXp: number;
  assessedLevel: UserLevel | null;
  assessedLevelTitle?: string;
  diagnosticCompleted: boolean;
  diagnosticResult?: {
    scorePercent: number;
    recommendedStartDay: number;
    level: UserLevel;
    categories: {
      logic: number;
      syntax: number;
      dataStructures: number;
      algorithms: number;
    };
    summary: string;
  };
  savedCodes: Record<number, Record<string, string>>;
  mockTestScores: Record<number, number>;
  bookmarkedDays: number[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  codeSnippet?: string;
}

export interface CodeEvaluationResult {
  overallStatus: 'passed' | 'partial' | 'failed';
  scorePercent: number;
  timeComplexity: string;
  spaceComplexity: string;
  testResults: {
    input: string;
    expected: string;
    actual: string;
    passed: boolean;
    explanation?: string;
  }[];
  mentorFeedback: string;
  strengths: string[];
  improvements: string[];
  edgeCasesConsidered?: string;
}
