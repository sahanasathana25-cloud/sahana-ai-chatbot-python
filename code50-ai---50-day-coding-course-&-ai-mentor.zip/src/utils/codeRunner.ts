import { TestCase, CodeEvaluationResult, LanguageKey, PreferredLanguage } from '../types';

export interface LocalExecutionResult {
  passed: boolean;
  actual: string;
  expected: string;
  logs: string[];
  executionTimeMs: number;
  error?: string;
}

export function executeJavaScriptInBrowser(
  userCode: string,
  testCase: TestCase
): LocalExecutionResult {
  const startTime = performance.now();
  const logs: string[] = [];

  // Intercept console.log
  const customConsole = {
    log: (...args: any[]) => {
      logs.push(args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '));
    },
    error: (...args: any[]) => {
      logs.push(`[Error] ${args.join(' ')}`);
    },
    warn: (...args: any[]) => {
      logs.push(`[Warn] ${args.join(' ')}`);
    },
  };

  try {
    // Construct function wrapper
    // The testCase.input usually looks like "a = 10, b = 20" or "n = 8" or "str = 'racecar'"
    // We parse and prepare arguments
    const runnerCode = `
      ${userCode}
      
      try {
        // Prepare inputs from testCase: "${testCase.input.replace(/"/g, '\\"')}"
        ${testCase.input};
        
        let __result;
        if (typeof solve === 'function') {
          // Detect argument names from testCase.input
          const inputStr = ${JSON.stringify(testCase.input)};
          const varAssignments = inputStr.split(',').map(s => s.trim());
          const varNames = varAssignments.map(v => v.split('=')[0].trim()).filter(Boolean);
          const args = varNames.map(name => {
            try { return eval(name); } catch(e) { return undefined; }
          });
          __result = solve(...args);
        } else {
          throw new Error("Function 'solve' is not defined in your code.");
        }
        return __result;
      } catch (err) {
        throw err;
      }
    `;

    // Wrap in sandboxed Function
    const fn = new Function('console', runnerCode);
    const rawResult = fn(customConsole);

    const executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
    const actualStr = JSON.stringify(rawResult);
    
    // Normalize comparison
    const normActual = normalizeValue(rawResult);
    const normExpected = normalizeExpected(testCase.expectedOutput);

    const passed = normActual === normExpected || actualStr === testCase.expectedOutput.trim();

    return {
      passed,
      actual: actualStr !== undefined ? actualStr : String(rawResult),
      expected: testCase.expectedOutput,
      logs,
      executionTimeMs,
    };
  } catch (err: any) {
    const executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
    return {
      passed: false,
      actual: 'Runtime Error',
      expected: testCase.expectedOutput,
      logs,
      executionTimeMs,
      error: err?.message || String(err),
    };
  }
}

function normalizeValue(val: any): string {
  if (val === undefined) return 'undefined';
  if (val === null) return 'null';
  if (typeof val === 'string') return val.trim();
  if (typeof val === 'number' || typeof val === 'boolean') return String(val);
  try {
    return JSON.stringify(val);
  } catch {
    return String(val);
  }
}

function normalizeExpected(expected: string): string {
  let trimmed = expected.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    trimmed = trimmed.slice(1, -1);
  }
  return trimmed;
}

// Full evaluation combining local execution for JS or AI judge for all languages
export async function evaluateCodeRemotely(
  problem: any,
  code: string,
  language: LanguageKey,
  preferredLanguage: PreferredLanguage,
  testCases: TestCase[]
): Promise<CodeEvaluationResult> {
  const response = await fetch('/api/evaluate-code', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      problem,
      code,
      language,
      preferredLanguage,
      testCases,
    }),
  });

  if (!response.ok) {
    throw new Error(`Evaluation failed with status ${response.status}`);
  }

  return response.json();
}
