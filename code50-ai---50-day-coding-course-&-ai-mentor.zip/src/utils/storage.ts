import { UserProgress } from '../types';

const STORAGE_KEY = 'code50_user_progress_v2';

export const INITIAL_PROGRESS: UserProgress = {
  userProfile: null,
  completedDays: [],
  currentDay: 1,
  streak: 1,
  lastActiveDate: new Date().toISOString().split('T')[0],
  totalXp: 0,
  assessedLevel: null,
  assessedLevelTitle: undefined,
  diagnosticCompleted: false,
  savedCodes: {},
  mockTestScores: {},
  bookmarkedDays: [],
};

export function loadUserProgress(): UserProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_PROGRESS;
    const parsed = JSON.parse(raw);
    
    // Check streak
    const today = new Date().toISOString().split('T')[0];
    const lastActive = parsed.lastActiveDate;
    let streak = parsed.streak || 1;

    if (lastActive && lastActive !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      if (lastActive !== yesterdayStr) {
        streak = 1; // missed a day, reset streak
      }
    }

    return {
      ...INITIAL_PROGRESS,
      ...parsed,
      streak,
      lastActiveDate: today,
    };
  } catch (err) {
    console.error('Failed to load user progress:', err);
    return INITIAL_PROGRESS;
  }
}

export function saveUserProgress(progress: UserProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (err) {
    console.error('Failed to save user progress:', err);
  }
}
